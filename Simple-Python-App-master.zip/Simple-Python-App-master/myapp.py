def run_myapp():
    print("It works!")
    return "It works"


if __name__ == "__main__":
    run_myapp()

